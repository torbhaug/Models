import numpy as np
from scipy import stats
#from scipy.stats import norm
import scipy.integrate as integrate
import matplotlib.pyplot as plt
import seaborn as sns
import math
from scipy.optimize import curve_fit

def main(diff_means, payoff_true_positive, payoff_true_negative, payoff_false_positive, payoff_false_negative, standard_deviation, positive_base_rate, negative_base_rate, sigma_m, sigma_t, n_cost):
    diff_means = diff_means
    tp_payoff = payoff_true_positive
    tn_payoff = payoff_true_negative
    fp_payoff = payoff_false_positive
    fn_payoff = payoff_false_negative
    SD = standard_deviation
    baserate_p = positive_base_rate
    baserate_n = negative_base_rate
    sigma_m = sigma_m
    sigma_t = sigma_t
    n_cost = n_cost

    global payoff
    payoff = []

    global dprime_value
    dprime_value = []

    global n_list

    n_list = []

    optimal_p, optimal_dprime = distributions(diff_means, tp_payoff, tn_payoff, fp_payoff, fn_payoff, SD, baserate_p, baserate_n, sigma_m, sigma_t, n_cost)

    #print("The scaling values of payoff is:", payoff)

    #xData = np.array(dprime_value)
    #yData = np.array(payoff)

    #plt.plot(xData, yData, 'b', label = 'Optimal payoff')
    #plt.xlabel("d'")
    #plt.ylabel('Payoff')
    #plt.legend()
    #plt.show()

    xData = np.array(dprime_value)
    yData = np.array(payoff)


    #xData = np.array(dprime_value)
    #yData = np.array(n_list)


    #plt.plot(xData, yData, 'b', label = 'N scaling')
    #plt.xlabel("d'")
    #plt.ylabel('n')
    #plt.legend()
    #plt.show()

    return optimal_p, optimal_dprime



def distributions(diff_means, tp_payoff, tn_payoff, fp_payoff, fn_payoff, SD, baserate_p, baserate_n, sigma_m, sigma_t, n_cost):

    global Apex
    Apex = False
    dprime = diff_means/(math.sqrt(sigma_t**2 + sigma_m**2))
    original_dprime = dprime
    #diff_means/np.sqrt((sigma_t)**2 + ((sigma_m)**2/n_cost))
    #p_avg = dprime
    #diff_means + dprime

    #setting the seeds for the negative distribution

    #n_seed = np.random.randint(10000)
    #np.random.seed(n_seed)
    #print("n_seed =", n_seed)

    #creates negative distribution
    #n_draw = np.random.normal(loc=0, scale=SD, size=1000)
    #N_draw = np.multiply(n_draw, baserate_n)

    #plt.hist(n_draw, bins=100)

    #count, bins, ignored = plt.hist(n_draw, 30, density=True)
    #plt.plot(bins, 1 / (SD * np.sqrt(2 * np.pi)) *
             #np.exp(- (bins - 0) ** 2 / (2 * SD ** 2)),
             #linewidth=2, color='r')

    #plt.show()

    #fitting variables to a normal dist function
    #n_loc, n_scale = stats.norm.fit(N_draw)x

    #creating a probability density function


    #plotting the pdf
    #plt.plot(x, n_dist, color= 'black')
    #plt.show()


    #print("Negative distribution is", n_dist)

    #setting seed for positive distribution
    #p_seed = np.random.randint(10000)
    #print("p_seed =", p_seed)

    first_run = True
    endpoint = diff_means**2/sigma_t**2
    highest_p = -1000
    optimal_dprime = 0

    while dprime < 1.98:
        if first_run == True:
            dprime += 0
            first_run = False
        elif first_run == False:
            dprime += 0.01 * (endpoint - original_dprime)
        dprime_value.append(dprime)
        n_val = (sigma_m**2)/((diff_means**2/dprime**2) - sigma_t**2) #there is a mistake here
        #print("The n value =", n_val)
        n = n_val * n_cost
        n_list.append(n)
        #print("N cost for value of d'", dprime, "=", n)
        srp = d_prime(dprime, tp_payoff, tn_payoff, fp_payoff, fn_payoff, SD, baserate_p, baserate_n, sigma_m, sigma_t, n)
        if srp > highest_p:
            highest_p = srp
            optimal_dprime = dprime

    return highest_p, optimal_dprime


def d_prime(dprime, tp_payoff, tn_payoff, fp_payoff, fn_payoff, SD, baserate_p, baserate_n, sigma_m, sigma_t, n):
    #, payoff_true_positive, payoff_true_negative, payoff_false_positive, payoff_false_negative, standard_deviation, positive_base_rate, negative_base_rate

    #creating positive distribution
    #np.random.seed(p_seed) should be unecessary

    #p_draw = np.random.normal(loc=dprime, scale=SD, size=1000)
    #P_draw = np.multiply(p_draw, baserate_p)

    #count, bins, ignored = plt.hist(p_draw, 30, density=True)
    #plt.plot(bins, 1 / (SD * np.sqrt(2 * np.pi)) *
            #np.exp(- (bins - 0) ** 2 / (2 * SD ** 2)),
             #linewidth=2, color='g')

    #count, bins, ignored = plt.hist(n_draw, 30, density=True)
    #plt.plot(bins, 1 / (SD * np.sqrt(2 * np.pi)) *
             #np.exp(- (bins - 0) ** 2 / (2 * SD ** 2)),
             #linewidth=2, color='r')

    #plt.show()

    n_loc = 0 - (dprime/2)
    x = np.linspace(start=-5, stop=4, num=100)
    n_dist = stats.norm.pdf(x, loc=n_loc, scale=SD)
    #print("N_dist is:", n_dist)



    #p_loc, p_scale = stats.norm.fit(P_draw)

    p_loc = 0 + dprime/2

    x = np.linspace(start=-4, stop=5, num=100)

    p_dist = stats.norm.pdf(x, loc=p_loc, scale=SD)
    #print("p_dist is:", p_dist)

    # plotting the pdf
    #plt.plot(x, p_dist, color='black')
    #plt.show()

    #print("Postitive distribution is", p_dist)


    #creating optimal criterion
    optimalC = optimal_C(dprime, baserate_p, baserate_n, tp_payoff, tn_payoff, fp_payoff, fn_payoff)


    #creating cumulative density functions for the misses
    x = np.linspace(start=-5, stop=4, num=100)

    ncdf_x = optimalC
    neg_cdf = stats.norm.cdf(x, loc=n_loc, scale=SD)

    opt_ncdf = stats.norm.cdf(ncdf_x, loc=n_loc, scale=SD)
    #print("cdf thang of tha negatives be", opt_ncdf)

    #print("Neg_cdf is", neg_cdf)

    #sns.lineplot(x=n_dist, y=neg_cdf)
    #plt.plot(x, neg_cdf, color='black')

    #plt.show()

    x = np.linspace(start=-4, stop=5, num=100)
    pcdf_x = optimalC
    pos_cdf = stats.norm.cdf(x, loc=p_loc, scale=SD)

    optc_pcdf = stats.norm.cdf(pcdf_x, loc=p_loc, scale=SD)
    #print("cdf thang for tha positives be", optc_pcdf)

    #plt.plot(x, pos_cdf, color='black')

    #plt.show()
    #sns.lineplot(x=p_dist, y=pos_cdf)

    #plt.show()

    #count, bins, ignored = plt.hist(p_dist, 30, density=True)
    #plt.plot(bins, 1 / (SD * np.sqrt(2 * np.pi)) *np.exp(- (bins - 0) ** 2 / (2 * SD ** 2)), linewidth=2, color='r')

    #count, bins, ignored = plt.hist(n_dist, 30, density=True)
    #plt.plot(bins, 1 / (SD * np.sqrt(2 * np.pi)) *np.exp(- (bins - dprime) ** 2 / (2 * SD ** 2)), linewidth=2, color='g')

    #plt.show()



    #determining relative hit/miss rate
    fp_auc = (optc_pcdf) * baserate_p

    tp_auc = (1 - optc_pcdf) * baserate_p

    tn_auc = (opt_ncdf) * baserate_n

    fn_auc = (1 - opt_ncdf) * baserate_n

    total = (fp_auc) + (fn_auc) + (tp_auc) + (tn_auc)

    hitrate_fp = (fp_auc) / total
    #print("fp-hit =", hitrate_fp)
    hitrate_fn = (fn_auc) / total
    #print("fn-hit=", hitrate_fn)
    hitrate_tp = (tp_auc) / total
    #print("tp-hit=", hitrate_tp)
    hitrate_tn = (tn_auc) / total
    #print("tn-hit=", hitrate_tn)


    #calculating payoff
    avg_payoff = average_payoff(hitrate_fp, hitrate_fn, hitrate_tp, hitrate_tn, fp_payoff, fn_payoff, tp_payoff,
                                tn_payoff, n)
    #print('Average payoff =', avg_payoff)
    #print("The avereage payoff for this value of d' =", avg_payoff)

    payoff.append(avg_payoff)

    #calculating slope of curve
    #p_mean = p_avg
    #n_mean = 0
    #slope_of_curve = (((1/((p_mean-n_mean)**2/((dprime))**2)) * math.sqrt(2 * math.pi))) * (((((1 - hitrate_tn) * np.exp(exponential("tneg", dprime, optimalC, p_mean, hitrate_tn))) * tn_payoff) + (1 - hitrate_fp) * ((1 - np.exp(exponential("fpos", dprime, optimalC, p_mean, hitrate_fp))) * fp_payoff) + ((hitrate_fn * (np.exp(exponential("fneg", dprime, optimalC, p_mean, hitrate_fn)))) * fn_payoff) + hitrate_tp * (1 - np.exp(exponential("tpos", dprime, optimalC, p_mean, hitrate_tp))) * tp_payoff)) - (2 * (sigma_m)**2/((((p_mean - n_mean)**2 /(dprime)**2) - sigma_t) * (dprime)**3))
    #print("When d' =", dprime, "The slope of the curve =", slope_of_curve)


    #if slope_of_curve <= 0:
        #Apex = True




    return avg_payoff






def optimal_C(dprime, baserate_p, baserate_n, payoff_tp, payoff_tn, payoff_fp, payoff_fn):
    try:
        check = 1/baserate_p-baserate_n

        optimalC = (np.log((((baserate_n * payoff_tn) - (payoff_fp * baserate_n)) / ((baserate_p * payoff_tp) - (baserate_p * payoff_fn))))) / dprime
    except:
        optimalC = (np.log((baserate_n)/(baserate_p)))/dprime
    return optimalC



def average_payoff(hitrate_fp, hitrate_fn, hitrate_tp, hitrate_tn, fp_payoff, fn_payoff, tp_payoff, tn_payoff, n):
    return hitrate_fp * fp_payoff + hitrate_fn * fn_payoff + hitrate_tp * tp_payoff + hitrate_tn * tn_payoff + n



print(main(2, 4, 0, -1, 0, 1, 0.3, 0.7, 1, 1.001, -0.01))


def varying_baserate(mean_baserate, standard_deviaton_baserate):
    participants = stats.norm.rvs(mean_baserate, standard_deviaton_baserate, 1000)
    participant_counter = 0
    optimalD = []
    partcipant_number = []
    for x in range(0, 999):
        participant_counter += 1
        participant_number.append(partcipant_counter)
        baserate_p = participants[x]
        baserate_n = 1 - baserate_p
        optimal_p, optimal_dprime = main(2, 2, 2, -1, -4, 1, baserate_p, baserate_n, 1, 1.001, -0.03)
        optimalD.append(optimal_dprime)

    return mean(optimalD)

def range_of_baserates(mean_baserate):
    d_for_range = []
    for x in range(0, 100, 1):
        SD = x/50
        d_for_range.append(varying_baserate(mean_baserate, SD))
    print("The optimal dprime for the different baserates are", d_for_range)
    return


def varying_of_baserates(diff_means, payoff_true_positive, payoff_true_negative, payoff_false_positive, payoff_false_negative, standard_deviation, sigma_m, sigma_t, n_cost):
    optimal_list = []
    baserates = []
    for x in range(1, 999):
        baserate_p = x / 1000
        print('The baserate is:', baserate_p)
        baserate_n = 1 - baserate_p
        #(baserate_n * payoff_true_negative) - (payoff_false_positive * baserate_n) != 0 or (baserate_p * payoff_true_positive) - (baserate_p * payoff_false_negative) != 0:
        baserates.append(baserate_p)
        avgp, optd = main(diff_means, payoff_true_positive, payoff_true_negative, payoff_false_positive, payoff_false_negative, standard_deviation, baserate_p, baserate_n, sigma_m, sigma_t, n_cost)
        optimal_list.append(optd)

    xData = np.array(baserates)
    yData = np.array(optimal_list)

    plt.plot(xData, yData, 'r', label = 'Varying baserates')
    plt.xlabel('Baserates')
    plt.ylabel('Optimal d')
    plt.legend()
    plt.show()

#varying_of_baserates(2, 4, 4, -4, -4, 1, 1, 1.001, -0.03)


def range_of_payoffs(diff_means, avg_payoff_true_positive, avg_payoff_true_negative, avg_payoff_false_positive, avg_payoff_false_negative, standard_deviation, SD_payoff, positive_base_rate, negative_base_rate, sigma_m, sigma_t, n_cost):
    participant_counter = 0
    optimalD = []
    #partcipant_number = []

    for x in range(0, 999):
        ptp = stats.norm.rvs(avg_payoff_true_positive, SD_payoff, 1)
        ptn = stats.norm.rvs(avg_payoff_true_negative, SD_payoff, 1)
        pfp = stats.norm.rvs(avg_payoff_false_positive, SD_payoff, 1)
        pfn = stats.norm.rvs(avg_payoff_false_negative, SD_payoff, 1)
        participant_counter += 1
        #participant_number.append(partcipant_counter)
        optimal_p, optimal_dprime = main(diff_means, ptp, ptn, pfp, pfn, standard_deviation, positive_base_rate, negative_base_rate, sigma_m, sigma_t, n_cost)
        optimalD.append(optimal_dprime)

    return np.mean(optimalD)

#print("With varying means the average d' is:", range_of_payoffs(2, 4, 4, -40, -4, 1, 0.75, 0.25, 1, 1, 1.001, -0.03))